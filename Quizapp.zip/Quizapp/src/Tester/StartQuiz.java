package Tester;

import java.sql.SQLException;
import java.util.Scanner;

import AllLogicClasses.AdminLogin;
//import AllLogicClasses.StudentLogin;
import AllLogicClasses.StudentRegAndLogin;

public class StartQuiz {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		StudentRegAndLogin obj = new StudentRegAndLogin();
		AdminLogin aobj = new AdminLogin();
		System.out.println("Welcome to Quiz Application");
		int ch = 0;
		
			System.out.println("\n1.Registraction" +
		"\n2.Login" + 
		"\n3.Login as Admin" + "\n 0.Exit");
			
			System.out.println("Enter Your Choice");
			ch = sc.nextInt();
			
			switch(ch) {
			case 1:
				System.out.println("Registraction");
				obj.registerStudent();
				break;
			case 2:
				System.out.println("Login");
				obj.login();
				break;
			case 3:
				aobj.login();
				break; 
			default:
				System.out.println("Please enter valid choice..");
			}
	}
}
		
		
	


