package AllLogicClasses;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.cj.protocol.x.SyncFlushDeflaterOutputStream;

import static DBConnection.CommonConnection.getConnection;

public class AdminLogin {

	private Connection cn;
	private PreparedStatement pst1;
	private PreparedStatement pst2;
	private PreparedStatement pst3;
	private PreparedStatement pst4;

	public AdminLogin() throws SQLException {
		super();
		this.cn = getConnection();
		pst1 = cn.prepareStatement("SELECT * FROM ad_min WHERE username= ? AND pasword = ?");
		pst2 = cn.prepareStatement("SELECT * FROM student ORDER BY Score ASC");
		pst3 = cn.prepareStatement("SELECT * FROM student WHERE ID = ?");
		//pst4 = cn.
	}

	public void login() throws SQLException {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter The UserName:");
		String username = sc.next();

		System.out.println("Enter The Password:");
		int password = sc.nextInt();

		pst1.setString(1, username);
		pst1.setLong(2, password);

		try (ResultSet rst = pst1.executeQuery()) {

			if (rst.next()) {
				System.out.println("Login Successful!!!");

				System.out.println("\n1.Display All students score in ascending order"
						+ "\n2.Fetch students score by using Id" + "\n3.Add Question With four Options");

				System.out.println("Enter Your Choice");
				int ch = sc.nextInt();

				switch (ch) {
				case 1:
					displayAllStudentsScore();
					break;
				case 2:
					System.out.println("Enter student id");
					int id = sc.nextInt();
					getStudentScorebyId(id);
					break;
				case 3:
					System.out.println("Login as Admin");
					break;

				default:
					System.out.println("Please enter valid choice..");
				}
			} else {
				System.out.println("Login failed!!!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void displayAllStudentsScore() {

		try (ResultSet rst  =pst2.executeQuery()){
			while(rst.next()) {
				System.out.println(rst.getInt(1) + " " + rst.getString(2) + " - " + rst.getInt(9));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void getStudentScorebyId(int id) throws SQLException {
		pst3.setInt(1, id);
		try (ResultSet rst  =pst3.executeQuery()){
			while(rst.next()) {
				System.out.println("Marks of the student = "+ rst.getInt(9));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void AddQuestion() {

	}

}
