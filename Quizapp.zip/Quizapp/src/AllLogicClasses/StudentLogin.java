/*package AllLogicClasses;

import static DBConnection.CommonConnection.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class StudentLogin {
	private Connection cn;
	private PreparedStatement pst1;
	
	public StudentLogin() throws SQLException{
		
		this.cn = getConnection();
		pst1 = cn.prepareStatement("SELECT * FROM student WHERE UserName= ? AND Pasword = ?");
	}
	public void login() throws SQLException {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter The UserName:");
		String username = sc.next();

		System.out.println("Enter The Password:");
		int password = sc.nextInt();

		pst1.setString(1, username);
		pst1.setLong(2, password);

		try (ResultSet rst = pst1.executeQuery()) {

			if (rst.next()) {
				System.out.println("Login Successful!!!");
				int stdId = rst.getInt(0);
				QuestionsDaoImpl obj = new QuestionsDaoImpl();
				
				obj.displayQuestions(stdId);
			} else {
				System.out.println("Login failed!!!");

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}*/

