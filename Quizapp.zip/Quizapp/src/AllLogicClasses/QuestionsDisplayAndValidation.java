package AllLogicClasses;

import static DBConnection.CommonConnection.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class QuestionsDisplayAndValidation {

	private Connection cn ;
	private PreparedStatement pst1;
	private PreparedStatement pst2;
	private PreparedStatement pst3;
	private PreparedStatement pst4;
	private PreparedStatement pst5;
	private PreparedStatement pst6;
	private PreparedStatement pst7;

	public QuestionsDisplayAndValidation() throws SQLException {
		super();
		this.cn = getConnection();
		pst1 = cn.prepareStatement("SELECT * FROM question");
		pst2 = cn.prepareStatement("SELECT * FROM options WHERE fkQiD = ?");
		pst3 = cn.prepareStatement("SELECT * FROM options where ID = ?");
		pst4 = cn.prepareStatement("UPDATE student SET Score=? WHERE id = ?");
		pst5 = cn.prepareStatement("SELECT * FROM student WHERE id = ?");
		pst6 = cn.prepareStatement("SELECT * FROM options WHERE AnswerId = ?");
		pst7 = cn.prepareStatement("SELECT * FROM student WHERE ID = ?");
	}

	public void displayQuestions(int stdId) {
		Scanner sc = new Scanner(System.in);
		int answer;
		try(ResultSet rst1 = pst1.executeQuery()) {
			while (rst1.next()) {
				System.out.println(rst1.getString(2)); //whatever the index for questions field in table
				int id = rst1.getInt(1);   // Questions Id
				pst2.setInt(1, id);
				try(ResultSet rst2 = pst2.executeQuery()) {
					int temp = 1;
					while(rst2.next()) {
						System.out.println(temp +") " +  rst2.getString(2));
						temp++;
					}
					System.out.println("Enter your answer -");
					answer = sc.nextInt();
					pst6.setInt(1, answer);
					ResultSet rst6 = pst6.executeQuery();// ******kahi error ahet ithun I think u can manage...
					int optionId= 0;
					if(rst6.next()) {
					optionId = rst6.getInt(1);
					}
					checkAnswers(stdId,answer, optionId);
				} catch (Exception e) {
					// Just for understanding cause we havent added custom exception remove this is it works fine
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			// Just for understanding cause we havent added custom exception remove this is it works fine
			System.out.println("Error in outer (Questions) while loop");
			e.printStackTrace();
		}
		System.out.println("Thank you for attending the Quizz..");
	}

	public void checkAnswers(int stdId, int answer, int optionId) throws SQLException {

		pst3.setInt(1 , optionId);
		
		try (ResultSet rst3 = pst3.executeQuery()){
			if(rst3.next()) {
			if(rst3.getBoolean(3)){
				pst5.setInt(1, stdId);
				ResultSet rst5 = pst5.executeQuery();
				int existingMarks=0;
				if(rst5.next()) 
				existingMarks  = rst5.getInt(9); //whatever the marks column index
				
				int newMarks = existingMarks +1;
				pst4.setInt(1, newMarks);
				pst4.setInt(2, stdId);
				pst4.executeUpdate();
			}
			else {}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void displayScore(int stdId) throws SQLException {
		pst7.setInt(1, stdId);
		try (ResultSet rst  =pst7.executeQuery()){
			while(rst.next()) {
				System.out.println("Marks of the student = "+ rst.getInt(9));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
