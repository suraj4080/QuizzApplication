package AllLogicClasses;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.cj.protocol.x.SyncFlushDeflaterOutputStream;

import static DBConnection.CommonConnection.getConnection;

public class StudentRegAndLogin {

	private Connection cn;
	private PreparedStatement pst1;
	private PreparedStatement pst2;

	public StudentRegAndLogin() throws SQLException {
		super();
		this.cn = getConnection();
		pst1 = cn.prepareStatement("SELECT * FROM student WHERE UserName= ? AND Pasword = ?");
		pst2 = cn.prepareStatement(
				"insert into student(Firstname,Lastname,Username,Pasword,City,Mail_Id,Mobile_no)values(?,?,?,?,?,?,?)");
	}

	public void registerStudent() throws SQLException {
		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter firstname");
		String firstname = sc.next();

		System.out.println("Please enter lastname");
		String lastname = sc.next();

		System.out.println("Enter The UserName:");
		String username = sc.next();

		System.out.println("Enter The Password:");
		int password = sc.nextInt();

		System.out.println("Enter The City:");
		String city = sc.next();

		System.out.println("Enter The Mail Id:");
		String mailId = sc.next();

		System.out.println("Mobile Number:");
		long mobileNumber = sc.nextLong();

		
		pst2.setString(1, firstname);
		pst2.setString(2, lastname);
		pst2.setString(3, username);
		pst2.setInt(4, password);
		pst2.setString(5, city);
		pst2.setString(6, mailId);
		pst2.setLong(7, mobileNumber);

		
		if (!pst2.execute()) {
			System.out.println("Registration Successful!!!");
		} else {
			System.out.println("Registration failed!!!");

		}
	}

	

	public void login() throws SQLException {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter The UserName:");
		String username = sc.next();

		System.out.println("Enter The Password:");
		int password = sc.nextInt();

		pst1.setString(1, username);
		pst1.setLong(2, password);

		try (ResultSet rst = pst1.executeQuery()) {

			if (rst.next()) {
				System.out.println("Login Successful!!!");
				int stdId = rst.getInt(1);
				System.out.println("Start the quiz");
				QuestionsDisplayAndValidation obj = new QuestionsDisplayAndValidation();
				
				System.out.println("\n1.Display your score"
						+ "\n2.Start the Quiz");

				System.out.println("Enter Your Choice");
				int ch = sc.nextInt();

				switch (ch) {
				case 1:
					obj.displayScore(stdId);
					break;
				case 2:
					obj.displayQuestions(stdId);
					break;
				default:
					System.out.println("Please enter valid choice..");
				}
				
			} else {
				System.out.println("Login failed!!!");

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
