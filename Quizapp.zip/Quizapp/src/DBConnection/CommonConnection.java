package DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CommonConnection {

	public static Connection getConnection() throws SQLException {
		Connection connection = null;
		
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/queans", "root", "Suraj@4080");

		

		return connection;
	}

}